fun main(){
    var nome:String = "Loja Varejo"
    lateinit var movimentoClientes:Short
    lateinit var endereco:String
    lateinit var lucroTotalMes:Int

    lateinit var funcionarios:Funcionarios
    lateinit var salarios:Salarios
    lateinit var estoque:Estoque
}