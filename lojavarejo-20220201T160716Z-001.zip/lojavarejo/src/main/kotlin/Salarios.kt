class Salarios {
    var salario1:String = "1,200"
    var salario2:String = "1,100"
    var salario3:String = "1,300"
    var salario4:String = "1,000"
    var salario5:String = "1,400"
}