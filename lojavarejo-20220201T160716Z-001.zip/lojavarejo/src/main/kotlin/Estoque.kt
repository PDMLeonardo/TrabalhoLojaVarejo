class Estoque {
    lateinit var adega:Short
    lateinit var alimentosPereciveis:Short
    lateinit var alimNaoPereciveis:Short
    lateinit var refrigerantes:Short
    lateinit var matLimpeza:Short
    lateinit var prodMiscelania:Short
}