class Funcionarios {
    lateinit var funcionario1:String
    lateinit var funcionario2:String
    lateinit var funcionario3:String
    lateinit var funcionario4:String
    lateinit var funcionario5:String
}