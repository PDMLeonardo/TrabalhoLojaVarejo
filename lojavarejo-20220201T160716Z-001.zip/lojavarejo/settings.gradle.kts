
rootProject.name = "lojadevarejo"

